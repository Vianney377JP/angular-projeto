export class Medico {
  id?: number;
  nome?: string;
  email?: string;
  crm?: string;
}
