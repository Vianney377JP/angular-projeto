import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-content-componet',
  templateUrl: './ng-content-componet.component.html',
  styleUrls: ['./ng-content-componet.component.scss']
})
export class NgContentComponetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
