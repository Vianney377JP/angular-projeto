import { CorDirective } from './cor.directive';

describe('CorDirective', () => {
  it('should create an instance', () => {
    const directive = new CorDirective();
    expect(directive).toBeTruthy();
  });
});
