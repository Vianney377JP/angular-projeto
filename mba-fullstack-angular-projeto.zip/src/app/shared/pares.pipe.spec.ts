import { ParesPipe } from './pares.pipe';

describe('ParesPipe', () => {
  it('create an instance', () => {
    const pipe = new ParesPipe();
    expect(pipe).toBeTruthy();
  });
});
