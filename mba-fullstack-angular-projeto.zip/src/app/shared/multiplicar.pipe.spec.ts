import { MultiplicarPipe } from './multiplicar.pipe';

describe('MultiplicarPipe', () => {
  it('create an instance', () => {
    const pipe = new MultiplicarPipe();
    expect(pipe).toBeTruthy();
  });
});
