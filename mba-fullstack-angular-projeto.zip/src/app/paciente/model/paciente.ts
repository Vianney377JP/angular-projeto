export class Paciente {
    id?: number;
    nome?: string;
    email?: string;
    crm?: string;
  }